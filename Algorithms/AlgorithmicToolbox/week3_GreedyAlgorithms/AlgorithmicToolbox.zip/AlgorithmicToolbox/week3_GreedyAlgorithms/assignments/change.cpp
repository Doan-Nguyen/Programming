#include <iostream>

using std::cin;
using std::cout;

int change(int money){
    
}