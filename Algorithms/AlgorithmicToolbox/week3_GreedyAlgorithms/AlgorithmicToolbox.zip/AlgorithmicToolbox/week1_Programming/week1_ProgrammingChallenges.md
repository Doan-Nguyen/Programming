# Programming Challenges

## Challenge: Improving the Naive Solution, Testing, Debugging
+ Problem: Max pairwise product 
    - Input: an array
    - Output: the max value of pairwise product
+ Example: 
    - input: [2, 3, 1, 6]
    - output: 18